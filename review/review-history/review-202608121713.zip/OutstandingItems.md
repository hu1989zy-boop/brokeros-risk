# Q-004 Final Outstanding Items

## Remaining Q-004 Work

None.

Q-004's blocking local/CI, Docker, MySQL, Flyway, Redis, Kafka, backend health,
Kustomize, static, and cleanup acceptance gates have passed. The first-run
failure was corrected by Patch-01 and superseded by successful GitHub Actions
run `31518167311` on commit `77229a2`.

## Known Non-Blocking Issues

- The developer host has no Docker daemon. Developers without Docker must rely
  on the successful CI runner or another approved isolated host for runtime
  infrastructure verification.
- Local Maven uses Java 23 with the project compiled for Java 21. Mockito warns
  that dynamic agent loading will be restricted by a future JDK.
- Pinned GitHub Actions and kubectl versions require deliberate maintenance.
- GitHub-hosted run logs have provider retention limits; the run/job IDs and
  repository-owned assertions should remain in Review evidence.

## Deferred Work

- CI performance optimization or job splitting.
- CD and production deployment automation.
- Shared BrokerOS framework extraction without a second proven consumer.
- Authentication, authorization/RBAC, API versioning, business ResultCodes,
  formal Audit, all risk modules, business tables, Kafka topics/events, Redis
  business keys, and real adapters.

These are explicitly outside Q-004 and are not defects in its closure.

## Residual Risks

- Future dependency, runner-image, Action, Docker image, or kubectl updates can
  regress CI and require routine maintenance.
- The Mockito/JDK warning should be resolved before it becomes a build failure.
- A future business migration still requires its own Requirement, migration
  review, compatibility analysis, and successful CI; Q-004 passing is not
  permission to invent one.

## Suggested Next Step

Stop after Q-004 closure. Await the formal approved Requirement for
`Q-005 — Foundation Hardening & Observability Baseline`.

Do not implement Q-005, Audit, RBAC, speculative domain events, Kafka topics,
or a top-level horizontal layer hierarchy from this Review closure.
